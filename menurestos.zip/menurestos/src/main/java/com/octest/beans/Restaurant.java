package com.octest.beans;

public class Restaurant {
	private String nom;
	private String Adresse;
	private String Description;
	private String Contacts;
	private String TypeRe;
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getAdresse() {
		return Adresse;
	}
	public void setAdresse(String adresse) {
		Adresse = adresse;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getContacts() {
		return Contacts;
	}
	public void setContacts(String contacts) {
		Contacts = contacts;
	}
	public String getTypeRe() {
		return TypeRe;
	}
	public void setTypeRe(String typeRe) {
		TypeRe = typeRe;
	}
	
	
}
