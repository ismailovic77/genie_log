package com.octest.bdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.octest.beans.Restaurant;

public class Restos {
	private Connection connexion;
	
	public List<Restaurant> recupererRestaurants() {
		List<Restaurant> restaurants = new ArrayList<Restaurant>();
		Statement statement = null;
		ResultSet resultat = null;
		
		loadDatabase();
		
		try {
			statement = connexion.createStatement();
			
			//execution de la requete
			resultat = statement.executeQuery("SELECT nom, adresse, description, contacts, typeRe, src_img FROM lrestos;");
			
			//recuperation des donnees
			while (resultat.next()) {
				String nom = resultat.getString("nom");
				String Adresse = resultat.getString("adresse");
				String Description = resultat.getString("description");
				String Contacts = resultat.getString("contacts");
				String TypeRe = resultat.getString("typeRe");
				String src_img = resultat.getString("src_img");
				
				Restaurant restaurant = new Restaurant();
				restaurant.setNom(nom);
				restaurant.setAdresse(Adresse);
				restaurant.setDescription(Description);
				restaurant.setContacts(Contacts);
				restaurant.setTypeRe(TypeRe);
				restaurant.setSrc_img(src_img);
				
				restaurants.add(restaurant);
			}
		} catch (SQLException e) {
		} finally {
			//fermeture de la connexion
			try {
				if (resultat != null)
					resultat.close();
				if (statement != null)
					statement.close();
				if (connexion != null)
					connexion.close();
			} catch (SQLException ignore) {
			}
		}
		
		return restaurants;
	}
	private void loadDatabase() {
		//chargement du driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
		}
		
		try {
			connexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/javaee","root", "5341");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void ajouterRestaurant(Restaurant restaurant) {
		loadDatabase();
		
		try {
			PreparedStatement preparedStatement = connexion.prepareStatement("INSERT INTO lrestos(nom, Adresse, Description, Contacts, TypeRe, src_img) VALUES(?, ?, ?, ?, ?, ?);");
			preparedStatement.setString(1, restaurant.getNom());
			preparedStatement.setString(2, restaurant.getAdresse());
			preparedStatement.setString(3, restaurant.getDescription());
			preparedStatement.setString(4, restaurant.getContacts());
			preparedStatement.setString(5, restaurant.getTypeRe());
			preparedStatement.setString(6, restaurant.getSrc_img());
			
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
