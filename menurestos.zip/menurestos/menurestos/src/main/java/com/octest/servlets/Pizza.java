package com.octest.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.octest.bdd.Restos;
import com.octest.beans.Restaurant;

/**
 * Servlet implementation class Pizza
 */
public class Pizza extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pizza() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Restos tableRestos = new Restos();
		request.setAttribute("restaurants", tableRestos.recupererRestaurants());
		this.getServletContext().getRequestDispatcher("/WEB-INF/Pizza.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Restaurant restaurant = new Restaurant();
		restaurant.setNom(request.getParameter("nom"));
		restaurant.setAdresse(request.getParameter("Adresse"));
		restaurant.setDescription(request.getParameter("Description"));
		restaurant.setContacts(request.getParameter("Contacts"));
		restaurant.setTypeRe(request.getParameter("TypeRe"));
		restaurant.setSrc_img(request.getParameter("src_img"));
		
		Restos tableRestos = new Restos();
		tableRestos.ajouterRestaurant(restaurant);
		
		request.setAttribute("restaurants", tableRestos.recupererRestaurants());
		
		this.getServletContext().getRequestDispatcher("/WEB-INF/Pizza.jsp").forward(request, response);
	}

}
